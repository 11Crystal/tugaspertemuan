<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Student Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        /* Login/Register Pages */
        .auth-container {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }

        .auth-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 40px;
            max-width: 450px;
            width: 100%;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .auth-header p {
            color: #666;
            font-size: 1.1em;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .auth-footer {
            text-align: center;
            margin-top: 20px;
            color: #666;
        }

        .auth-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-footer a:hover {
            text-decoration: underline;
        }

        /* Main Application Layout */
        .app-container {
            display: none;
        }

        .app-container.active {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #2d3748 0%, #1a202c 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h2 {
            font-size: 1.3em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.85em;
            opacity: 0.7;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: rgba(255, 255, 255, 0.8);
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .menu-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-left: 4px solid #ffd700;
        }

        .menu-item-icon {
            font-size: 1.3em;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            flex: 1;
            background: #f5f7fa;
        }

        .top-bar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar-title h1 {
            color: #2d3748;
            font-size: 1.8em;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1em;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            color: #2d3748;
        }

        .user-role {
            font-size: 0.85em;
            color: #718096;
        }

        .btn-logout {
            padding: 8px 20px;
            background: #e53e3e;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #c53030;
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }

        .page-content {
            display: none;
        }

        .page-content.active {
            display: block;
        }

        /* Dashboard Cards */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .stat-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5em;
        }

        .stat-icon.blue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .stat-icon.green {
            background: linear-gradient(135deg, #56ab2f 0%, #a8e063 100%);
            color: white;
        }

        .stat-icon.orange {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }

        .stat-icon.red {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
        }

        .stat-value {
            font-size: 2.5em;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #718096;
            font-size: 0.95em;
        }

        /* Tables */
        .data-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }

        .table-header {
            padding: 20px 25px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            color: #2d3748;
            font-size: 1.5em;
        }

        .btn-add {
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .table-content {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: #f8f9fa;
        }

        table th {
            padding: 15px;
            text-align: left;
            color: #2d3748;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        table td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            color: #4a5568;
        }

        table tbody tr:hover {
            background: #f8f9fa;
        }

        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9em;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-right: 5px;
        }

        .btn-edit {
            background: #4299e1;
            color: white;
        }

        .btn-edit:hover {
            background: #3182ce;
        }

        .btn-delete {
            background: #fc8181;
            color: white;
        }

        .btn-delete:hover {
            background: #f56565;
        }

        .btn-view {
            background: #48bb78;
            color: white;
        }

        .btn-view:hover {
            background: #38a169;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #2d3748;
            font-size: 1.8em;
        }

        .btn-close {
            background: none;
            border: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #718096;
            transition: all 0.3s ease;
        }

        .btn-close:hover {
            color: #2d3748;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Status Badges */
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .badge-active {
            background: #c6f6d5;
            color: #22543d;
        }

        .badge-inactive {
            background: #fed7d7;
            color: #742a2a;
        }

        .badge-graduated {
            background: #bee3f8;
            color: #2c5282;
        }

        .badge-present {
            background: #c6f6d5;
            color: #22543d;
        }

        .badge-absent {
            background: #fed7d7;
            color: #742a2a;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #a0aec0;
        }

        .empty-state-icon {
            font-size: 4em;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }

        .alert.active {
            display: block;
        }

        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #38a169;
        }

        .alert-error {
            background: #fed7d7;
            color: #742a2a;
            border-left: 4px solid #e53e3e;
        }

        /* Profile Card */
        .profile-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 25px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5em;
            font-weight: bold;
        }

        .profile-info h2 {
            color: #2d3748;
            font-size: 2em;
            margin-bottom: 5px;
        }

        .profile-info p {
            color: #718096;
            font-size: 1.1em;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }

        .info-item label {
            display: block;
            color: #718096;
            font-size: 0.9em;
            margin-bottom: 5px;
        }

        .info-item p {
            color: #2d3748;
            font-weight: 600;
            font-size: 1.1em;
        }

        /* Guest Banner */
        .guest-banner {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 15px 30px;
            text-align: center;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }

            .main-content {
                margin-left: 70px;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }

            .top-bar {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body class="login-page">
    <!-- Login Page -->
    <div id="loginPage" class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1>🎓 Welcome Back</h1>
                <p>Sign in to your account</p>
            </div>
            <div id="loginAlert" class="alert"></div>
            <form id="loginForm">
                <div class="form-group">
                    <label for="loginEmail">Email</label>
                    <input type="email" id="loginEmail" required placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
            <div class="auth-footer">
                <p>Don't have an account? <a href="#" onclick="showRegisterPage()">Register here</a></p>
                <p style="margin-top: 10px;"><a href="#" onclick="loginAsGuest()">Continue as Guest</a></p>
            </div>
            <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 0.9em;">
                <strong>Demo Accounts:</strong><br>
                Admin: admin@school.com / admin123<br>
                Lecturer: lecturer@school.com / lecturer123<br>
                Student: student@school.com / student123
            </div>
        </div>
    </div>

    <!-- Register Page -->
    <div id="registerPage" class="auth-container" style="display: none;">
        <div class="auth-card">
            <div class="auth-header">
                <h1>📝 Create Account</h1>
                <p>Join our education platform</p>
            </div>
            <div id="registerAlert" class="alert"></div>
            <form id="registerForm">
                <div class="form-group">
                    <label for="registerName">Full Name</label>
                    <input type="text" id="registerName" required placeholder="Enter your full name">
                </div>
                <div class="form-group">
                    <label for="registerEmail">Email</label>
                    <input type="email" id="registerEmail" required placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="registerPassword">Password</label>
                    <input type="password" id="registerPassword" required placeholder="Create a password">
                </div>
                <div class="form-group">
                    <label for="registerRole">Register as</label>
                    <select id="registerRole" required>
                        <option value="">Select Role</option>
                        <option value="student">Student</option>
                        <option value="lecturer">Lecturer</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
            <div class="auth-footer">
                <p>Already have an account? <a href="#" onclick="showLoginPage()">Login here</a></p>
            </div>
        </div>
    </div>

    <!-- Main Application -->
    <div id="appContainer" class="app-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>🎓 SMS</h2>
                <p id="sidebarRole">Admin Panel</p>
            </div>
            <div class="sidebar-menu" id="sidebarMenu">
                <!-- Menu items will be dynamically loaded -->
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Guest Banner -->
            <div id="guestBanner" class="guest-banner" style="display: none;">
                ⚠️ You are browsing as a Guest. Some features are limited. Please register or login for full access.
            </div>

            <!-- Top Bar -->
            <div class="top-bar">
                <div class="top-bar-title">
                    <h1 id="pageTitle">Dashboard</h1>
                </div>
                <div class="user-info">
                    <div class="user-avatar" id="userAvatar">A</div>
                    <div class="user-details">
                        <div class="user-name" id="userName">Admin User</div>
                        <div class="user-role" id="userRole">Administrator</div>
                    </div>
                    <button class="btn-logout" onclick="logout()">Logout</button>
                </div>
            </div>

            <!-- Content Area -->
            <div class="content-area">
                <!-- Page 1: Dashboard -->
                <div id="dashboardPage" class="page-content active">
                    <div class="dashboard-grid">
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon blue">👨‍🎓</div>
                            </div>
                            <div class="stat-value" id="dashTotalStudents">0</div>
                            <div class="stat-label">Total Students</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon green">👨‍🏫</div>
                            </div>
                            <div class="stat-value" id="dashTotalLecturers">0</div>
                            <div class="stat-label">Total Lecturers</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon orange">📚</div>
                            </div>
                            <div class="stat-value" id="dashTotalCourses">0</div>
                            <div class="stat-label">Total Courses</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon red">✅</div>
                            </div>
                            <div class="stat-value" id="dashAttendanceRate">0%</div>
                            <div class="stat-label">Attendance Rate</div>
                        </div>
                    </div>

                    <div class="data-table">
                        <div class="table-header">
                            <h2>Recent Activities</h2>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Activity</th>
                                        <th>User</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody id="recentActivities">
                                    <tr>
                                        <td colspan="4" class="empty-state">
                                            <div class="empty-state-icon">📊</div>
                                            <h3>No activities yet</h3>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 2: Student Management -->
                <div id="studentManagementPage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>Student Management</h2>
                            <button class="btn-add" onclick="openStudentModal()">+ Add Student</button>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Major</th>
                                        <th>Semester</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="studentsTableBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 3: Student List (Card View) -->
                <div id="studentListPage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>All Students</h2>
                        </div>
                        <div style="padding: 25px;">
                            <div class="dashboard-grid" id="studentCardsContainer"></div>
                        </div>
                    </div>
                </div>

                <!-- Page 4: Lecturer Management -->
                <div id="lecturerManagementPage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>Lecturer Management</h2>
                            <button class="btn-add" onclick="openLecturerModal()">+ Add Lecturer</button>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Lecturer ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Department</th>
                                        <th>Specialization</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="lecturersTableBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 5: Course Management -->
                <div id="courseManagementPage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>Course Management</h2>
                            <button class="btn-add" onclick="openCourseModal()">+ Add Course</button>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Course Code</th>
                                        <th>Course Name</th>
                                        <th>Credits</th>
                                        <th>Lecturer</th>
                                        <th>Semester</th>
                                        <th>Enrolled</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="coursesTableBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 6: Attendance -->
                <div id="attendancePage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>Attendance Management</h2>
                            <button class="btn-add" onclick="openAttendanceModal()">+ Mark Attendance</button>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Course</th>
                                        <th>Student</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="attendanceTableBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 7: Grade Management -->
                <div id="gradeManagementPage" class="page-content">
                    <div class="data-table">
                        <div class="table-header">
                            <h2>Grade Management</h2>
                            <button class="btn-add" onclick="openGradeModal()">+ Add Grade</button>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Course</th>
                                        <th>Assignment</th>
                                        <th>Midterm</th>
                                        <th>Final</th>
                                        <th>Total</th>
                                        <th>Grade</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="gradesTableBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 8: Reports -->
                <div id="reportsPage" class="page-content">
                    <div class="dashboard-grid">
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon blue">📊</div>
                            </div>
                            <div class="stat-value" id="reportActiveStudents">0</div>
                            <div class="stat-label">Active Students</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon green">🎓</div>
                            </div>
                            <div class="stat-value" id="reportGraduated">0</div>
                            <div class="stat-label">Graduated Students</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon orange">📈</div>
                            </div>
                            <div class="stat-value" id="reportAvgGrade">0</div>
                            <div class="stat-label">Average Grade</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-header">
                                <div class="stat-icon red">📚</div>
                            </div>
                            <div class="stat-value" id="reportActiveCourses">0</div>
                            <div class="stat-label">Active Courses</div>
                        </div>
                    </div>

                    <div class="data-table">
                        <div class="table-header">
                            <h2>Performance by Major</h2>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Major</th>
                                        <th>Students</th>
                                        <th>Average Grade</th>
                                        <th>Attendance Rate</th>
                                    </tr>
                                </thead>
                                <tbody id="majorReportsBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 9: Profile -->
                <div id="profilePage" class="page-content">
                    <div class="profile-card">
                        <div class="profile-header">
                            <div class="profile-avatar" id="profileAvatar">A</div>
                            <div class="profile-info">
                                <h2 id="profileName">User Name</h2>
                                <p id="profileRole">Role</p>
                            </div>
                        </div>
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Email</label>
                                <p id="profileEmail">-</p>
                            </div>
                            <div class="info-item">
                                <label>User ID</label>
                                <p id="profileId">-</p>
                            </div>
                            <div class="info-item" id="profileMajorItem" style="display: none;">
                                <label>Major</label>
                                <p id="profileMajor">-</p>
                            </div>
                            <div class="info-item" id="profileSemesterItem" style="display: none;">
                                <label>Semester</label>
                                <p id="profileSemester">-</p>
                            </div>
                            <div class="info-item" id="profileDeptItem" style="display: none;">
                                <label>Department</label>
                                <p id="profileDept">-</p>
                            </div>
                            <div class="info-item" id="profileSpecItem" style="display: none;">
                                <label>Specialization</label>
                                <p id="profileSpec">-</p>
                            </div>
                        </div>
                    </div>

                    <div class="data-table" id="profileCoursesSection" style="display: none;">
                        <div class="table-header">
                            <h2>My Courses</h2>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Course Code</th>
                                        <th>Course Name</th>
                                        <th>Credits</th>
                                        <th>Lecturer</th>
                                    </tr>
                                </thead>
                                <tbody id="profileCoursesBody"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="data-table" id="profileGradesSection" style="display: none;">
                        <div class="table-header">
                            <h2>My Grades</h2>
                        </div>
                        <div class="table-content">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Course</th>
                                        <th>Assignment</th>
                                        <th>Midterm</th>
                                        <th>Final</th>
                                        <th>Total</th>
                                        <th>Grade</th>
                                    </tr>
                                </thead>
                                <tbody id="profileGradesBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Page 10: Settings -->
                <div id="settingsPage" class="page-content">
                    <div class="profile-card">
                        <h2 style="margin-bottom: 25px; color: #2d3748;">System Settings</h2>
                        <div class="form-group">
                            <label>School Name</label>
                            <input type="text" id="settingSchoolName" value="University of Excellence" placeholder="Enter school name">
                        </div>
                        <div class="form-group">
                            <label>Academic Year</label>
                            <input type="text" id="settingAcademicYear" value="2024/2025" placeholder="e.g., 2024/2025">
                        </div>
                        <div class="form-group">
                            <label>Current Semester</label>
                            <select id="settingCurrentSemester">
                                <option value="1">Semester 1</option>
                                <option value="2">Semester 2</option>
                            </select>
                        </div>
                        <button class="btn-submit" onclick="saveSettings()">Save Settings</button>
                    </div>

                    <div class="profile-card" style="margin-top: 25px;">
                        <h2 style="margin-bottom: 25px; color: #2d3748;">Change Password</h2>
                        <div id="passwordAlert" class="alert"></div>
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" id="currentPassword" placeholder="Enter current password">
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" id="newPassword" placeholder="Enter new password">
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" id="confirmPassword" placeholder="Confirm new password">
                        </div>
                        <button class="btn-submit" onclick="changePassword()">Change Password</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <!-- Student Modal -->
    <div id="studentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="studentModalTitle">Add Student</h2>
                <button class="btn-close" onclick="closeStudentModal()">&times;</button>
            </div>
            <form id="studentForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Student ID</label>
                        <input type="text" id="studentId" required placeholder="e.g., 2024001">
                    </div>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="studentName" required placeholder="Enter full name">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="studentEmail" required placeholder="student@example.com">
                    </div>
                    <div class="form-group">
                        <label>Major</label>
                        <select id="studentMajor" required>
                            <option value="">Select Major</option>
                            <option value="Information Systems">Information Systems</option>
                            <option value="Accounting">Accounting</option>
                            <option value="Entrepreneurship">Entrepreneurship</option>
                            <option value="Management">Management</option>
                            <option value="Hospitality">Hospitality</option>
                            <option value="International Trade">International Trade</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Semester</label>
                        <select id="studentSemester" required>
                            <option value="">Select Semester</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select id="studentStatus" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Graduated">Graduated</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn-submit">Save Student</button>
            </form>
        </div>
    </div>

    <!-- Lecturer Modal -->
    <div id="lecturerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="lecturerModalTitle">Add Lecturer</h2>
                <button class="btn-close" onclick="closeLecturerModal()">&times;</button>
            </div>
            <form id="lecturerForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Lecturer ID</label>
                        <input type="text" id="lecturerId" required placeholder="e.g., L001">
                    </div>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="lecturerName" required placeholder="Enter full name">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="lecturerEmail" required placeholder="lecturer@example.com">
                    </div>
                    <div class="form-group">
                        <label>Department</label>
                        <select id="lecturerDept" required>
                            <option value="">Select Department</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Business">Business</option>
                            <option value="Engineering">Engineering</option>
                            <option value="Arts">Arts</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Specialization</label>
                        <input type="text" id="lecturerSpec" required placeholder="e.g., Database Systems">
                    </div>
                </div>
                <button type="submit" class="btn-submit">Save Lecturer</button>
            </form>
        </div>
    </div>

    <!-- Course Modal -->
    <div id="courseModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="courseModalTitle">Add Course</h2>
                <button class="btn-close" onclick="closeCourseModal()">&times;</button>
            </div>
            <form id="courseForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Course Code</label>
                        <input type="text" id="courseCode" required placeholder="e.g., CS101">
                    </div>
                    <div class="form-group">
                        <label>Course Name</label>
                        <input type="text" id="courseName" required placeholder="Enter course name">
                    </div>
                    <div class="form-group">
                        <label>Credits</label>
                        <input type="number" id="courseCredits" required min="1" max="6" placeholder="e.g., 3">
                    </div>
                    <div class="form-group">
                        <label>Lecturer</label>
                        <select id="courseLecturer" required>
                            <option value="">Select Lecturer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Semester</label>
                        <select id="courseSemester" required>
                            <option value="">Select Semester</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn-submit">Save Course</button>
            </form>
        </div>
    </div>

    <!-- Attendance Modal -->
    <div id="attendanceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Mark Attendance</h2>
                <button class="btn-close" onclick="closeAttendanceModal()">&times;</button>
            </div>
            <form id="attendanceForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" id="attendanceDate" required>
                    </div>
                    <div class="form-group">
                        <label>Course</label>
                        <select id="attendanceCourse" required>
                            <option value="">Select Course</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Student</label>
                        <select id="attendanceStudent" required>
                            <option value="">Select Student</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select id="attendanceStatus" required>
                            <option value="Present">Present</option>
                            <option value="Absent">Absent</option>
                            <option value="Late">Late</option>
                            <option value="Excused">Excused</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn-submit">Save Attendance</button>
            </form>
        </div>
    </div>

    <!-- Grade Modal -->
    <div id="gradeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="gradeModalTitle">Add Grade</h2>
                <button class="btn-close" onclick="closeGradeModal()">&times;</button>
            </div>
            <form id="gradeForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Student</label>
                        <select id="gradeStudent" required>
                            <option value="">Select Student</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Course</label>
                        <select id="gradeCourse" required>
                            <option value="">Select Course</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Assignment (0-100)</label>
                        <input type="number" id="gradeAssignment" required min="0" max="100" placeholder="0-100">
                    </div>
                    <div class="form-group">
                        <label>Midterm (0-100)</label>
                        <input type="number" id="gradeMidterm" required min="0" max="100" placeholder="0-100">
                    </div>
                    <div class="form-group">
                        <label>Final (0-100)</label>
                        <input type="number" id="gradeFinal" required min="0" max="100" placeholder="0-100">
                    </div>
                </div>
                <button type="submit" class="btn-submit">Save Grade</button>
            </form>
        </div>
    </div>

    <script>
        // Data Storage
        let currentUser = null;
        let users = [
            { id: 'U001', name: 'Admin User', email: 'admin@school.com', password: 'admin123', role: 'admin' },
            { id: 'U002', name: 'Dr. John Smith', email: 'lecturer@school.com', password: 'lecturer123', role: 'lecturer', lecturerId: 'L001', department: 'Computer Science', specialization: 'Database Systems' },
            { id: 'U003', name: 'Jane Doe', email: 'student@school.com', password: 'student123', role: 'student', studentId: 'S001', major: 'Information Systems', semester: '3' }
        ];
        
        let students = [
            { id: 'S001', name: 'Jane Doe', email: 'student@school.com', major: 'Information Systems', semester: '3', status: 'Active' },
            { id: 'S002', name: 'John Wilson', email: 'john@school.com', major: 'Accounting', semester: '5', status: 'Active' }
        ];
        
        let lecturers = [
            { id: 'L001', name: 'Dr. John Smith', email: 'lecturer@school.com', department: 'Computer Science', specialization: 'Database Systems' },
            { id: 'L002', name: 'Dr. Sarah Johnson', email: 'sarah@school.com', department: 'Business', specialization: 'Marketing' }
        ];
        
        let courses = [
            { code: 'CS101', name: 'Introduction to Programming', credits: 3, lecturer: 'Dr. John Smith', semester: '1', enrolled: 45 },
            { code: 'BUS201', name: 'Business Management', credits: 3, lecturer: 'Dr. Sarah Johnson', semester: '2', enrolled: 38 }
        ];
        
        let attendance = [
            { date: '2024-11-20', course: 'CS101', student: 'Jane Doe', status: 'Present' },
            { date: '2024-11-21', course: 'CS101', student: 'John Wilson', status: 'Absent' }
        ];
        
        let grades = [
            { student: 'Jane Doe', course: 'CS101', assignment: 85, midterm: 90, final: 88, total: 87.67, grade: 'A' },
            { student: 'John Wilson', course: 'BUS201', assignment: 78, midterm: 82, final: 80, total: 80, grade: 'B+' }
        ];

        let editingIndex = -1;
        let editingType = '';

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Set today's date for attendance
            const today = new Date().toISOString().split('T')[0];
            if (document.getElementById('attendanceDate')) {
                document.getElementById('attendanceDate').value = today;
            }
        });

        // Authentication Functions
        function showLoginPage() {
            document.getElementById('loginPage').style.display = 'flex';
            document.getElementById('registerPage').style.display = 'none';
            document.body.className = 'login-page';
        }

        function showRegisterPage() {
            document.getElementById('loginPage').style.display = 'none';
            document.getElementById('registerPage').style.display = 'flex';
            document.body.className = 'login-page';
        }

        function loginAsGuest() {
            currentUser = {
                id: 'GUEST',
                name: 'Guest User',
                email: 'guest@system.com',
                role: 'guest'
            };
            initializeApp();
            document.getElementById('guestBanner').style.display = 'block';
        }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            const user = users.find(u => u.email === email && u.password === password);
            
            if (user) {
                currentUser = user;
                initializeApp();
            } else {
                showAlert('loginAlert', 'Invalid email or password', 'error');
            }
        });

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const role = document.getElementById('registerRole').value;
            
            if (users.find(u => u.email === email)) {
                showAlert('registerAlert', 'Email already exists', 'error');
                return;
            }
            
            const newUser = {
                id: 'U' + (users.length + 1).toString().padStart(3, '0'),
                name,
                email,
                password,
                role
            };
            
            if (role === 'student') {
                newUser.studentId = 'S' + (students.length + 1).toString().padStart(3, '0');
                newUser.major = '';
                newUser.semester = '1';
                students.push({
                    id: newUser.studentId,
                    name,
                    email,
                    major: 'Not Set',
                    semester: '1',
                    status: 'Active'
                });
            } else if (role === 'lecturer') {
                newUser.lecturerId = 'L' + (lecturers.length + 1).toString().padStart(3, '0');
                newUser.department = '';
                newUser.specialization = '';
                lecturers.push({
                    id: newUser.lecturerId,
                    name,
                    email,
                    department: 'Not Set',
                    specialization: 'Not Set'
                });
            }
            
            users.push(newUser);
            showAlert('registerAlert', 'Registration successful! Please login.', 'success');
            
            setTimeout(() => {
                showLoginPage();
            }, 2000);
        });

        function logout() {
            currentUser = null;
            document.getElementById('appContainer').classList.remove('active');
            document.getElementById('loginPage').style.display = 'flex';
            document.getElementById('registerPage').style.display = 'none';
            document.body.className = 'login-page';
            document.getElementById('guestBanner').style.display = 'none';
        }

        function initializeApp() {
            document.getElementById('loginPage').style.display = 'none';
            document.getElementById('registerPage').style.display = 'none';
            document.getElementById('appContainer').classList.add('active');
            document.body.className = 'logged-in';
            
            // Update user info
            const initials = currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            document.getElementById('userAvatar').textContent = initials;
            document.getElementById('userName').textContent = currentUser.name;
            document.getElementById('userRole').textContent = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
            
            // Load sidebar menu based on role
            loadSidebarMenu();
            
            // Load dashboard
            showPage('dashboard');
            updateDashboard();
        }

        function loadSidebarMenu() {
            const menu = document.getElementById('sidebarMenu');
            const roleText = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
            document.getElementById('sidebarRole').textContent = roleText + ' Panel';
            
            let menuItems = [];
            
            if (currentUser.role === 'admin') {
                menuItems = [
                    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
                    { id: 'studentManagement', icon: '👨‍🎓', label: 'Students' },
                    { id: 'studentList', icon: '📋', label: 'Student List' },
                    { id: 'lecturerManagement', icon: '👨‍🏫', label: 'Lecturers' },
                    { id: 'courseManagement', icon: '📚', label: 'Courses' },
                    { id: 'attendance', icon: '✅', label: 'Attendance' },
                    { id: 'gradeManagement', icon: '📝', label: 'Grades' },
                    { id: 'reports', icon: '📈', label: 'Reports' },
                    { id: 'profile', icon: '👤', label: 'Profile' },
                    { id: 'settings', icon: '⚙️', label: 'Settings' }
                ];
            } else if (currentUser.role === 'lecturer') {
                menuItems = [
                    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
                    { id: 'studentList', icon: '📋', label: 'Students' },
                    { id: 'courseManagement', icon: '📚', label: 'My Courses' },
                    { id: 'attendance', icon: '✅', label: 'Attendance' },
                    { id: 'gradeManagement', icon: '📝', label: 'Grades' },
                    { id: 'profile', icon: '👤', label: 'Profile' },
                    { id: 'settings', icon: '⚙️', label: 'Settings' }
                ];
            } else if (currentUser.role === 'student') {
                menuItems = [
                    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
                    { id: 'courseManagement', icon: '📚', label: 'My Courses' },
                    { id: 'attendance', icon: '✅', label: 'My Attendance' },
                    { id: 'gradeManagement', icon: '📝', label: 'My Grades' },
                    { id: 'profile', icon: '👤', label: 'Profile' },
                    { id: 'settings', icon: '⚙️', label: 'Settings' }
                ];
            } else {
                // Guest
                menuItems = [
                    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
                    { id: 'studentList', icon: '📋', label: 'Students' },
                    { id: 'courseManagement', icon: '📚', label: 'Courses' }
                ];
            }
            
            menu.innerHTML = menuItems.map(item => `
                <div class="menu-item" onclick="showPage('${item.id}')">
                    <span class="menu-item-icon">${item.icon}</span>
                    <span>${item.label}</span>
                </div>
            `).join('');
        }

        function showPage(pageId) {
            // Remove active class from all pages and menu items
            document.querySelectorAll('.page-content').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
            
            // Add active class to selected page
            const page = document.getElementById(pageId + 'Page');
            if (page) {
                page.classList.add('active');
                
                // Update page title
                const titles = {
                    dashboard: 'Dashboard',
                    studentManagement: 'Student Management',
                    studentList: 'Student List',
                    lecturerManagement: 'Lecturer Management',
                    courseManagement: 'Course Management',
                    attendance: 'Attendance',
                    gradeManagement: 'Grade Management',
                    reports: 'Reports & Analytics',
                    profile: 'My Profile',
                    settings: 'Settings'
                };
                document.getElementById('pageTitle').textContent = titles[pageId] || 'Dashboard';
                
                // Add active class to menu item
                const menuItems = document.querySelectorAll('.menu-item');
                menuItems.forEach((item, index) => {
                    if (item.onclick && item.onclick.toString().includes(pageId)) {
                        item.classList.add('active');
                    }
                });
                
                // Load page data
                if (pageId === 'dashboard') updateDashboard();
                else if (pageId === 'studentManagement') renderStudentsTable();
                else if (pageId === 'studentList') renderStudentCards();
                else if (pageId === 'lecturerManagement') renderLecturersTable();
                else if (pageId === 'courseManagement') renderCoursesTable();
                else if (pageId === 'attendance') renderAttendanceTable();
                else if (pageId === 'gradeManagement') renderGradesTable();
                else if (pageId === 'reports') updateReports();
                else if (pageId === 'profile') loadProfile();
            }
        }

        // Dashboard Functions
        function updateDashboard() {
            document.getElementById('dashTotalStudents').textContent = students.length;
            document.getElementById('dashTotalLecturers').textContent = lecturers.length;
            document.getElementById('dashTotalCourses').textContent = courses.length;
            
            const presentCount = attendance.filter(a => a.status === 'Present').length;
            const totalAttendance = attendance.length;
            const attendanceRate = totalAttendance > 0 ? ((presentCount / totalAttendance) * 100).toFixed(0) : 0;
            document.getElementById('dashAttendanceRate').textContent = attendanceRate + '%';
        }

        // Student Management Functions
        function renderStudentsTable() {
            const tbody = document.getElementById('studentsTableBody');
            
            if (students.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><div class="empty-state-icon">👨‍🎓</div><h3>No students yet</h3></td></tr>';
                return;
            }
            
            tbody.innerHTML = students.map((student, index) => `
                <tr>
                    <td>${student.id}</td>
                    <td>${student.name}</td>
                    <td>${student.email}</td>
                    <td>${student.major}</td>
                    <td>${student.semester}</td>
                    <td><span class="badge badge-${student.status.toLowerCase()}">${student.status}</span></td>
                    <td>
                        <button class="btn-action btn-edit" onclick="editStudent(${index})">Edit</button>
                        <button class="btn-action btn-delete" onclick="deleteStudent(${index})">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        function renderStudentCards() {
            const container = document.getElementById('studentCardsContainer');
            
            if (students.length === 0) {
                container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">👨‍🎓</div><h3>No students yet</h3></div>';
                return;
            }
            
            container.innerHTML = students.map(student => {
                const initials = student.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                return `
                    <div class="stat-card">
                        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                            <div style="width: 50px; height: 50px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 1.2em;">
                                ${initials}
                            </div>
                            <div>
                                <div style="font-weight: bold; color: #2d3748; font-size: 1.1em;">${student.name}</div>
                                <div style="color: #718096; font-size: 0.9em;">${student.id}</div>
                            </div>
                        </div>
                        <div style="font-size: 0.9em; color: #4a5568; line-height: 1.8;">
                            <div><strong>Email:</strong> ${student.email}</div>
                            <div><strong>Major:</strong> ${student.major}</div>
                            <div><strong>Semester:</strong> ${student.semester}</div>
                            <div><strong>Status:</strong> <span class="badge badge-${student.status.toLowerCase()}">${student.status}</span></div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function openStudentModal() {
            if (currentUser.role === 'guest') {
                alert('Guests cannot add students. Please register or login.');
                return;
            }
            document.getElementById('studentModal').classList.add('active');
            document.getElementById('studentModalTitle').textContent = 'Add Student';
            document.getElementById('studentForm').reset();
            editingIndex = -1;
            editingType = 'student';
        }

        function closeStudentModal() {
            document.getElementById('studentModal').classList.remove('active');
            editingIndex = -1;
        }

        function editStudent(index) {
            if (currentUser.role === 'guest') {
                alert('Guests cannot edit students. Please register or login.');
                return;
            }
            editingIndex = index;
            editingType = 'student';
            const student = students[index];
            
            document.getElementById('studentId').value = student.id;
            document.getElementById('studentName').value = student.name;
            document.getElementById('studentEmail').value = student.email;
            document.getElementById('studentMajor').value = student.major;
            document.getElementById('studentSemester').value = student.semester;
            document.getElementById('studentStatus').value = student.status;
            
            document.getElementById('studentModalTitle').textContent = 'Edit Student';
            document.getElementById('studentModal').classList.add('active');
        }

        function deleteStudent(index) {
            if (currentUser.role === 'guest') {
                alert('Guests cannot delete students. Please register or login.');
                return;
            }
            if (confirm('Are you sure you want to delete this student?')) {
                students.splice(index, 1);
                renderStudentsTable();
                renderStudentCards();
                updateDashboard();
            }
        }

        document.getElementById('studentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const student = {
                id: document.getElementById('studentId').value,
                name: document.getElementById('studentName').value,
                email: document.getElementById('studentEmail').value,
                major: document.getElementById('studentMajor').value,
                semester: document.getElementById('studentSemester').value,
                status: document.getElementById('studentStatus').value
            };
            
            if (editingIndex === -1) {
                students.push(student);
            } else {
                students[editingIndex] = student;
            }
            
            closeStudentModal();
            renderStudentsTable();
            renderStudentCards();
            updateDashboard();
        });

        // Lecturer Management Functions
        function renderLecturersTable() {
            const tbody = document.getElementById('lecturersTableBody');
            
            if (lecturers.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="empty-state"><div class="empty-state-icon">👨‍🏫</div><h3>No lecturers yet</h3></td></tr>';
                return;
            }
            
            tbody.innerHTML = lecturers.map((lecturer, index) => `
                <tr>
                    <td>${lecturer.id}</td>
                    <td>${lecturer.name}</td>
                    <td>${lecturer.email}</td>
                    <td>${lecturer.department}</td>
                    <td>${lecturer.specialization}</td>
                    <td>
                        <button class="btn-action btn-edit" onclick="editLecturer(${index})">Edit</button>
                        <button class="btn-action btn-delete" onclick="deleteLecturer(${index})">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        function openLecturerModal() {
            if (currentUser.role !== 'admin') {
                alert('Only administrators can add lecturers.');
                return;
            }
            document.getElementById('lecturerModal').classList.add('active');
            document.getElementById('lecturerModalTitle').textContent = 'Add Lecturer';
            document.getElementById('lecturerForm').reset();
            editingIndex = -1;
            editingType = 'lecturer';
        }

        function closeLecturerModal() {
            document.getElementById('lecturerModal').classList.remove('active');
            editingIndex = -1;
        }

        function editLecturer(index) {
            if (currentUser.role !== 'admin') {
                alert('Only administrators can edit lecturers.');
                return;
            }
            editingIndex = index;
            editingType = 'lecturer';
            const lecturer = lecturers[index];
            
            document.getElementById('lecturerId').value = lecturer.id;
            document.getElementById('lecturerName').value = lecturer.name;
            document.getElementById('lecturerEmail').value = lecturer.email;
            document.getElementById('lecturerDept').value = lecturer.department;
            document.getElementById('lecturerSpec').value = lecturer.specialization;
            
            document.getElementById('lecturerModalTitle').textContent = 'Edit Lecturer';
            document.getElementById('lecturerModal').classList.add('active');
        }

        function deleteLecturer(index) {
            if (currentUser.role !== 'admin') {
                alert('Only administrators can delete lecturers.');
                return;
            }
            if (confirm('Are you sure you want to delete this lecturer?')) {
                lecturers.splice(index, 1);
                renderLecturersTable();
                updateDashboard();
            }
        }

        document.getElementById('lecturerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const lecturer = {
                id: document.getElementById('lecturerId').value,
                name: document.getElementById('lecturerName').value,
                email: document.getElementById('lecturerEmail').value,
                department: document.getElementById('lecturerDept').value,
                specialization: document.getElementById('lecturerSpec').value
            };
            
            if (editingIndex === -1) {
                lecturers.push(lecturer);
            } else {
                lecturers[editingIndex] = lecturer;
            }
            
            closeLecturerModal();
            renderLecturersTable();
            updateDashboard();
            updateLecturerDropdowns();
        });

        // Course Management Functions
        function renderCoursesTable() {
            const tbody = document.getElementById('coursesTableBody');
            
            if (courses.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><div class="empty-state-icon">📚</div><h3>No courses yet</h3></td></tr>';
                return;
            }
            
            tbody.innerHTML = courses.map((course, index) => `
                <tr>
                    <td>${course.code}</td>
                    <td>${course.name}</td>
                    <td>${course.credits}</td>
                    <td>${course.lecturer}</td>
                    <td>${course.semester}</td>
                    <td>${course.enrolled || 0}</td>
                    <td>
                        <button class="btn-action btn-edit" onclick="editCourse(${index})">Edit</button>
                        <button class="btn-action btn-delete" onclick="deleteCourse(${index})">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        function openCourseModal() {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to add courses.');
                return;
            }
            updateLecturerDropdowns();
            document.getElementById('courseModal').classList.add('active');
            document.getElementById('courseModalTitle').textContent = 'Add Course';
            document.getElementById('courseForm').reset();
            editingIndex = -1;
            editingType = 'course';
        }

        function closeCourseModal() {
            document.getElementById('courseModal').classList.remove('active');
            editingIndex = -1;
        }

        function editCourse(index) {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to edit courses.');
                return;
            }
            editingIndex = index;
            editingType = 'course';
            const course = courses[index];
            
            updateLecturerDropdowns();
            document.getElementById('courseCode').value = course.code;
            document.getElementById('courseName').value = course.name;
            document.getElementById('courseCredits').value = course.credits;
            document.getElementById('courseLecturer').value = course.lecturer;
            document.getElementById('courseSemester').value = course.semester;
            
            document.getElementById('courseModalTitle').textContent = 'Edit Course';
            document.getElementById('courseModal').classList.add('active');
        }

        function deleteCourse(index) {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to delete courses.');
                return;
            }
            if (confirm('Are you sure you want to delete this course?')) {
                courses.splice(index, 1);
                renderCoursesTable();
                updateDashboard();
            }
        }

        function updateLecturerDropdowns() {
            const lecturerSelect = document.getElementById('courseLecturer');
            lecturerSelect.innerHTML = '<option value="">Select Lecturer</option>' +
                lecturers.map(l => `<option value="${l.name}">${l.name}</option>`).join('');
        }

        document.getElementById('courseForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const course = {
                code: document.getElementById('courseCode').value,
                name: document.getElementById('courseName').value,
                credits: parseInt(document.getElementById('courseCredits').value),
                lecturer: document.getElementById('courseLecturer').value,
                semester: document.getElementById('courseSemester').value,
                enrolled: editingIndex === -1 ? 0 : courses[editingIndex].enrolled
            };
            
            if (editingIndex === -1) {
                courses.push(course);
            } else {
                courses[editingIndex] = course;
            }
            
            closeCourseModal();
            renderCoursesTable();
            updateDashboard();
            updateCourseDropdowns();
        });

        // Attendance Functions
        function renderAttendanceTable() {
            const tbody = document.getElementById('attendanceTableBody');
            
            if (attendance.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="empty-state"><div class="empty-state-icon">✅</div><h3>No attendance records yet</h3></td></tr>';
                return;
            }
            
            tbody.innerHTML = attendance.map((record, index) => `
                <tr>
                    <td>${record.date}</td>
                    <td>${record.course}</td>
                    <td>${record.student}</td>
                    <td><span class="badge badge-${record.status.toLowerCase()}">${record.status}</span></td>
                    <td>
                        <button class="btn-action btn-delete" onclick="deleteAttendance(${index})">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        function openAttendanceModal() {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to mark attendance.');
                return;
            }
            updateCourseDropdowns();
            updateStudentDropdowns();
            document.getElementById('attendanceModal').classList.add('active');
            document.getElementById('attendanceForm').reset();
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('attendanceDate').value = today;
        }

        function closeAttendanceModal() {
            document.getElementById('attendanceModal').classList.remove('active');
        }

        function deleteAttendance(index) {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to delete attendance.');
                return;
            }
            if (confirm('Are you sure you want to delete this attendance record?')) {
                attendance.splice(index, 1);
                renderAttendanceTable();
                updateDashboard();
            }
        }

        function updateCourseDropdowns() {
            const courseSelects = ['attendanceCourse', 'gradeCourse'];
            courseSelects.forEach(id => {
                const select = document.getElementById(id);
                if (select) {
                    select.innerHTML = '<option value="">Select Course</option>' +
                        courses.map(c => `<option value="${c.code}">${c.code} - ${c.name}</option>`).join('');
                }
            });
        }

        function updateStudentDropdowns() {
            const studentSelects = ['attendanceStudent', 'gradeStudent'];
            studentSelects.forEach(id => {
                const select = document.getElementById(id);
                if (select) {
                    select.innerHTML = '<option value="">Select Student</option>' +
                        students.map(s => `<option value="${s.name}">${s.id} - ${s.name}</option>`).join('');
                }
            });
        }

        document.getElementById('attendanceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const record = {
                date: document.getElementById('attendanceDate').value,
                course: document.getElementById('attendanceCourse').value,
                student: document.getElementById('attendanceStudent').value,
                status: document.getElementById('attendanceStatus').value
            };
            
            attendance.push(record);
            closeAttendanceModal();
            renderAttendanceTable();
            updateDashboard();
        });

        // Grade Management Functions
        function renderGradesTable() {
            const tbody = document.getElementById('gradesTableBody');
            
            if (grades.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="empty-state"><div class="empty-state-icon">📝</div><h3>No grades yet</h3></td></tr>';
                return;
            }
            
            tbody.innerHTML = grades.map((grade, index) => `
                <tr>
                    <td>${grade.student}</td>
                    <td>${grade.course}</td>
                    <td>${grade.assignment}</td>
                    <td>${grade.midterm}</td>
                    <td>${grade.final}</td>
                    <td>${grade.total}</td>
                    <td><span class="badge badge-active">${grade.grade}</span></td>
                    <td>
                        <button class="btn-action btn-edit" onclick="editGrade(${index})">Edit</button>
                        <button class="btn-action btn-delete" onclick="deleteGrade(${index})">Delete</button>
                    </td>
                </tr>
            `).join('');
        }

        function openGradeModal() {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to add grades.');
                return;
            }
            updateCourseDropdowns();
            updateStudentDropdowns();
            document.getElementById('gradeModal').classList.add('active');
            document.getElementById('gradeModalTitle').textContent = 'Add Grade';
            document.getElementById('gradeForm').reset();
            editingIndex = -1;
            editingType = 'grade';
        }

        function closeGradeModal() {
            document.getElementById('gradeModal').classList.remove('active');
            editingIndex = -1;
        }

        function editGrade(index) {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to edit grades.');
                return;
            }
            editingIndex = index;
            editingType = 'grade';
            const grade = grades[index];
            
            updateCourseDropdowns();
            updateStudentDropdowns();
            document.getElementById('gradeStudent').value = grade.student;
            document.getElementById('gradeCourse').value = grade.course;
            document.getElementById('gradeAssignment').value = grade.assignment;
            document.getElementById('gradeMidterm').value = grade.midterm;
            document.getElementById('gradeFinal').value = grade.final;
            
            document.getElementById('gradeModalTitle').textContent = 'Edit Grade';
            document.getElementById('gradeModal').classList.add('active');
        }

        function deleteGrade(index) {
            if (currentUser.role === 'guest' || currentUser.role === 'student') {
                alert('You do not have permission to delete grades.');
                return;
            }
            if (confirm('Are you sure you want to delete this grade?')) {
                grades.splice(index, 1);
                renderGradesTable();
            }
        }

        function calculateGrade(total) {
            if (total >= 85) return 'A';
            if (total >= 80) return 'A-';
            if (total >= 75) return 'B+';
            if (total >= 70) return 'B';
            if (total >= 65) return 'B-';
            if (total >= 60) return 'C+';
            if (total >= 55) return 'C';
            if (total >= 50) return 'D';
            return 'F';
        }

        document.getElementById('gradeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const assignment = parseFloat(document.getElementById('gradeAssignment').value);
            const midterm = parseFloat(document.getElementById('gradeMidterm').value);
            const final = parseFloat(document.getElementById('gradeFinal').value);
            const total = ((assignment * 0.3) + (midterm * 0.3) + (final * 0.4)).toFixed(2);
            
            const grade = {
                student: document.getElementById('gradeStudent').value,
                course: document.getElementById('gradeCourse').value,
                assignment,
                midterm,
                final,
                total: parseFloat(total),
                grade: calculateGrade(parseFloat(total))
            };
            
            if (editingIndex === -1) {
                grades.push(grade);
            } else {
                grades[editingIndex] = grade;
            }
            
            closeGradeModal();
            renderGradesTable();
        });

        // Reports Functions
        function updateReports() {
            const activeStudents = students.filter(s => s.status === 'Active').length;
            const graduatedStudents = students.filter(s => s.status === 'Graduated').length;
            const avgGrade = grades.length > 0 ? (grades.reduce((sum, g) => sum + g.total, 0) / grades.length).toFixed(1) : 0;
            const activeCourses = courses.length;
            
            document.getElementById('reportActiveStudents').textContent = activeStudents;
            document.getElementById('reportGraduated').textContent = graduatedStudents;
            document.getElementById('reportAvgGrade').textContent = avgGrade;
            document.getElementById('reportActiveCourses').textContent = activeCourses;
            
            // Performance by Major
            const majorStats = {};
            students.forEach(s => {
                if (!majorStats[s.major]) {
                    majorStats[s.major] = { count: 0, totalGrade: 0, gradeCount: 0, attendance: 0, attendanceCount: 0 };
                }
                majorStats[s.major].count++;
                
                const studentGrades = grades.filter(g => g.student === s.name);
                studentGrades.forEach(g => {
                    majorStats[s.major].totalGrade += g.total;
                    majorStats[s.major].gradeCount++;
                });
                
                const studentAttendance = attendance.filter(a => a.student === s.name);
                const presentCount = studentAttendance.filter(a => a.status === 'Present').length;
                majorStats[s.major].attendance += presentCount;
                majorStats[s.major].attendanceCount += studentAttendance.length;
            });
            
            const tbody = document.getElementById('majorReportsBody');
            tbody.innerHTML = Object.keys(majorStats).map(major => {
                const stats = majorStats[major];
                const avgGrade = stats.gradeCount > 0 ? (stats.totalGrade / stats.gradeCount).toFixed(1) : '-';
                const attendanceRate = stats.attendanceCount > 0 ? ((stats.attendance / stats.attendanceCount) * 100).toFixed(0) + '%' : '-';
                
                return `
                    <tr>
                        <td>${major}</td>
                        <td>${stats.count}</td>
                        <td>${avgGrade}</td>
                        <td>${attendanceRate}</td>
                    </tr>
                `;
            }).join('');
        }

        // Profile Functions
        function loadProfile() {
            const initials = currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            document.getElementById('profileAvatar').textContent = initials;
            document.getElementById('profileName').textContent = currentUser.name;
            document.getElementById('profileRole').textContent = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
            document.getElementById('profileEmail').textContent = currentUser.email;
            document.getElementById('profileId').textContent = currentUser.id;
            
            // Hide all role-specific fields first
            document.getElementById('profileMajorItem').style.display = 'none';
            document.getElementById('profileSemesterItem').style.display = 'none';
            document.getElementById('profileDeptItem').style.display = 'none';
            document.getElementById('profileSpecItem').style.display = 'none';
            document.getElementById('profileCoursesSection').style.display = 'none';
            document.getElementById('profileGradesSection').style.display = 'none';
            
            if (currentUser.role === 'student') {
                const student = students.find(s => s.id === currentUser.studentId);
                if (student) {
                    document.getElementById('profileMajorItem').style.display = 'block';
                    document.getElementById('profileSemesterItem').style.display = 'block';
                    document.getElementById('profileMajor').textContent = student.major;
                    document.getElementById('profileSemester').textContent = student.semester;
                    
                    // Show student courses and grades
                    document.getElementById('profileCoursesSection').style.display = 'block';
                    document.getElementById('profileGradesSection').style.display = 'block';
                    
                    const studentGrades = grades.filter(g => g.student === currentUser.name);
                    document.getElementById('profileGradesBody').innerHTML = studentGrades.map(g => `
                        <tr>
                            <td>${g.course}</td>
                            <td>${g.assignment}</td>
                            <td>${g.midterm}</td>
                            <td>${g.final}</td>
                            <td>${g.total}</td>
                            <td><span class="badge badge-active">${g.grade}</span></td>
                        </tr>
                    `).join('') || '<tr><td colspan="6" class="empty-state">No grades yet</td></tr>';
                }
            } else if (currentUser.role === 'lecturer') {
                const lecturer = lecturers.find(l => l.id === currentUser.lecturerId);
                if (lecturer) {
                    document.getElementById('profileDeptItem').style.display = 'block';
                    document.getElementById('profileSpecItem').style.display = 'block';
                    document.getElementById('profileDept').textContent = lecturer.department;
                    document.getElementById('profileSpec').textContent = lecturer.specialization;
                    
                    // Show lecturer courses
                    document.getElementById('profileCoursesSection').style.display = 'block';
                    const lecturerCourses = courses.filter(c => c.lecturer === currentUser.name);
                    document.getElementById('profileCoursesBody').innerHTML = lecturerCourses.map(c => `
                        <tr>
                            <td>${c.code}</td>
                            <td>${c.name}</td>
                            <td>${c.credits}</td>
                            <td>${c.lecturer}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" class="empty-state">No courses assigned yet</td></tr>';
                }
            }
        }

        // Settings Functions
        function saveSettings() {
            if (currentUser.role !== 'admin') {
                alert('Only administrators can modify system settings.');
                return;
            }
            alert('Settings saved successfully!');
        }

        function changePassword() {
            const current = document.getElementById('currentPassword').value;
            const newPass = document.getElementById('newPassword').value;
            const confirm = document.getElementById('confirmPassword').value;
            
            if (!current || !newPass || !confirm) {
                showAlert('passwordAlert', 'Please fill all fields', 'error');
                return;
            }
            
            if (currentUser.password !== current) {
                showAlert('passwordAlert', 'Current password is incorrect', 'error');
                return;
            }
            
            if (newPass !== confirm) {
                showAlert('passwordAlert', 'New passwords do not match', 'error');
                return;
            }
            
            currentUser.password = newPass;
            const userIndex = users.findIndex(u => u.id === currentUser.id);
            if (userIndex !== -1) {
                users[userIndex].password = newPass;
            }
            
            showAlert('passwordAlert', 'Password changed successfully!', 'success');
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        }

        // Utility Functions
        function showAlert(elementId, message, type) {
            const alert = document.getElementById(elementId);
            alert.textContent = message;
            alert.className = 'alert active alert-' + type;
            setTimeout(() => {
                alert.classList.remove('active');
            }, 3000);
        }
    </script>
</body>
</html>