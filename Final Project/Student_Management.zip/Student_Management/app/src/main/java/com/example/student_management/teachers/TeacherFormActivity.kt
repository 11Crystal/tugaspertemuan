package com.example.student_management.teachers

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityTeacherFormBinding
import com.example.student_management.models.Teacher
import com.example.student_management.repositories.TeacherRepository

class TeacherFormActivity : AppCompatActivity() {

    private lateinit var b: ActivityTeacherFormBinding
    private var editingTeacher: Teacher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeacherFormBinding.inflate(layoutInflater)
        setContentView(b.root)

        val teacherId = intent.getStringExtra("id")

        if (teacherId != null) {
            editingTeacher = TeacherRepository.getTeacherById(teacherId)
            editingTeacher?.let { fillForm(it) }
        }

        b.btnSaveTeacher.setOnClickListener {
            save()
        }
    }

    private fun fillForm(t: Teacher) {
        b.edtTeacherId.setText(t.id)
        b.edtTeacherId.isEnabled = false
        b.edtTeacherName.setText(t.name)
        b.edtTeacherAddress.setText(t.address)
        b.edtTeacherSubject.setText(t.subjectSpecialization)
    }

    private fun save() {
        val id = b.edtTeacherId.text.toString()
        val name = b.edtTeacherName.text.toString()
        val address = b.edtTeacherAddress.text.toString()
        val subject = b.edtTeacherSubject.text.toString()

        if (id.isEmpty() || name.isEmpty()) {
            Toast.makeText(this, "ID & Name required", Toast.LENGTH_SHORT).show()
            return
        }

        if (editingTeacher == null) {
            TeacherRepository.addTeacher(
                Teacher(id, name, address, "-", subject)
            )
            Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show()
        } else {
            editingTeacher!!.name = name
            editingTeacher!!.address = address
            editingTeacher!!.subjectSpecialization = subject
            Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show()
        }

        finish()
    }
}
