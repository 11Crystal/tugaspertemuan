package com.example.student_management.repositories

import com.example.student_management.models.Subject

class SubjectRepository {

    private val subjects = ArrayList<Subject>()

    fun addSubject(subject: Subject) {
        subjects.add(subject)
    }

    fun updateSubject(updatedSubject: Subject) {
        val index = subjects.indexOfFirst { it.id == updatedSubject.id }
        if (index != -1) {
            subjects[index] = updatedSubject
        }
    }

    fun deleteSubject(subjectId: String) {
        subjects.removeIf { it.id == subjectId }
    }

    fun getAllSubjects(): List<Subject> {
        return subjects
    }

    fun getSubjectById(subjectId: String): Subject? {
        return subjects.find { it.id == subjectId }
    }

    fun generateSubjectId(): String {
        val nextId = subjects.size + 1
        return "SUB" + nextId.toString().padStart(3, '0')
    }
}
