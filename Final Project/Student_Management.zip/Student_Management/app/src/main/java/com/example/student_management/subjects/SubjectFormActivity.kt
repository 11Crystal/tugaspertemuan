package com.example.student_management.subjects

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivitySubjectFormBinding
import com.example.student_management.models.Subject
import com.example.student_management.repositories.SubjectRepository

class SubjectFormActivity : AppCompatActivity() {

    private lateinit var b: ActivitySubjectFormBinding
    private var editing: Subject? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySubjectFormBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getStringExtra("id")
        if (id != null) {
            editing = SubjectRepository.getSubjectById(id)
            editing?.let { fill(it) }
        }

        b.btnSaveSubject.setOnClickListener { save() }
    }

    private fun fill(s: Subject) {
        b.edtSubjectId.setText(s.id)
        b.edtSubjectId.isEnabled = false
        b.edtSubjectName.setText(s.name)
        b.edtTeacherId.setText(s.teacherId)
    }

    private fun save() {
        val id = b.edtSubjectId.text.toString().trim()
        val name = b.edtSubjectName.text.toString().trim()
        val teacherId = b.edtTeacherId.text.toString().trim()

        if (id.isEmpty() || name.isEmpty()) {
            Toast.makeText(this, "ID & name required", Toast.LENGTH_SHORT).show()
            return
        }

        if (editing == null) {
            SubjectRepository.addSubject(Subject(id, name, teacherId))
            Toast.makeText(this, "Subject added", Toast.LENGTH_SHORT).show()
        } else {
            editing!!.name = name
            editing!!.teacherId = teacherId
            Toast.makeText(this, "Subject updated", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
