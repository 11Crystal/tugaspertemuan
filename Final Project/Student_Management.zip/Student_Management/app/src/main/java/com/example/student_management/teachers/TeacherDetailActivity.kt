package com.example.student_management.teachers

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityTeacherDetailBinding
import com.example.student_management.repositories.TeacherRepository

class TeacherDetailActivity : AppCompatActivity() {

    private lateinit var b: ActivityTeacherDetailBinding
    private var id: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeacherDetailBinding.inflate(layoutInflater)
        setContentView(b.root)

        id = intent.getStringExtra("id")

        load()

        b.btnEditTeacher.setOnClickListener {
            val intent = Intent(this, TeacherFormActivity::class.java)
            intent.putExtra("id", id)
            startActivity(intent)
        }

        b.btnDeleteTeacher.setOnClickListener {
            confirmDelete()
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        val t = id?.let { TeacherRepository.getTeacherById(it) } ?: return

        b.tvTeacherId.text = "ID: ${t.id}"
        b.tvTeacherName.text = "Name: ${t.name}"
        b.tvTeacherAddress.text = "Address: ${t.address}"
        b.tvTeacherSubject.text = "Subject: ${t.subjectSpecialization}"
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete Teacher?")
            .setPositiveButton("Delete") { _: DialogInterface, _: Int ->
                id?.let { TeacherRepository.deleteTeacher(it) }
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
