package com.example.student_management.repositories

import com.example.student_management.models.Grade

class GradeRepository {

    private val grades = ArrayList<Grade>()

    fun addGrade(grade: Grade) {
        grades.add(grade)
    }

    fun updateGrade(updated: Grade) {
        val index = grades.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            grades[index] = updated
        }
    }

    fun deleteGrade(gradeId: String) {
        grades.removeIf { it.id == gradeId }
    }

    fun getAllGrades(): List<Grade> {
        return grades
    }

    fun getGradeById(gradeId: String): Grade? {
        return grades.find { it.id == gradeId }
    }

    fun generateGradeId(): String {
        val nextId = grades.size + 1
        return "G" + nextId.toString().padStart(3, '0')
    }
}
