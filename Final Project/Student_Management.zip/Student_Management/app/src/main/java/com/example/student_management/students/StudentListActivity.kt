package com.example.student_management.subjects

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivitySubjectListBinding
import com.example.student_management.models.Subject
import com.example.student_management.repositories.SubjectRepository

class SubjectListActivity : AppCompatActivity() {

    private lateinit var b: ActivitySubjectListBinding
    private lateinit var adapter: SubjectAdapter
    private var subjects = ArrayList<Subject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySubjectListBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnAddSubject.setOnClickListener {
            startActivity(Intent(this, SubjectFormActivity::class.java))
        }

        b.listSubjects.setOnItemClickListener { _, _, pos, _ ->
            val intent = Intent(this, SubjectDetailActivity::class.java)
            intent.putExtra("id", SubjectRepository.getAllSubjects()[pos].id)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        subjects = ArrayList(SubjectRepository.getAllSubjects())
        adapter = SubjectAdapter(this, subjects)
        b.listSubjects.adapter = adapter
    }
}
