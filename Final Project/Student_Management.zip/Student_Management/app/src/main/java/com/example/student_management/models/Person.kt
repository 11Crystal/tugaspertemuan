package com.example.student_management.models

open class Person(
    open val id: String,
    open var name: String,
    open var address: String,
    open var parentName: String
)
