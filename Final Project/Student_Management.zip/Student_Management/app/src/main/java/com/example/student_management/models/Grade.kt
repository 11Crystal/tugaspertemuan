package com.example.student_management.models

class Grade(
    val id: String,                   // G001
    val studentId: String,            // S001
    val subjectId: String,            // SUB001
    var score: Int                    // 0 - 100
)
