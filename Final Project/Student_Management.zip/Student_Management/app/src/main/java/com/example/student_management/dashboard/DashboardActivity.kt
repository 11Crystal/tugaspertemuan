package com.example.student_management.dashboard

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityDashboardBinding
import com.example.student_management.students.StudentListActivity
import com.example.student_management.teachers.TeacherListActivity
import com.example.student_management.subjects.SubjectListActivity
import com.example.student_management.attendance.AttendanceActivity
import com.example.student_management.grades.GradeActivity
import com.example.student_management.reports.ReportActivity

class DashboardActivity : AppCompatActivity() {

    private lateinit var b: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Click listeners untuk pindah activity
        b.btnStudents.setOnClickListener {
            startActivity(Intent(this, StudentListActivity::class.java))
        }

        b.btnTeachers.setOnClickListener {
            startActivity(Intent(this, TeacherListActivity::class.java))
        }

        b.btnSubjects.setOnClickListener {
            startActivity(Intent(this, SubjectListActivity::class.java))
        }

        b.btnAttendance.setOnClickListener {
            startActivity(Intent(this, AttendanceActivity::class.java))
        }

        b.btnGrades.setOnClickListener {
            startActivity(Intent(this, GradeActivity::class.java))
        }

        b.btnReports.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
    }
}
