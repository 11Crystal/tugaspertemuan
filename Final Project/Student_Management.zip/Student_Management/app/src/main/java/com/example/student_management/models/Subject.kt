package com.example.student_management.models

class Subject(
    val id: String,                   // SUB001
    var name: String,                 // "Mathematics"
    var teacherId: String             // T001
)
