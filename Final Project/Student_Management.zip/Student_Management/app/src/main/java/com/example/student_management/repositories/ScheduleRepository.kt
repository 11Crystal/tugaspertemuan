package com.example.student_management.repositories

import com.example.student_management.models.Schedule

class ScheduleRepository {

    private val schedules = ArrayList<Schedule>()

    fun addSchedule(schedule: Schedule) {
        schedules.add(schedule)
    }

    fun updateSchedule(updatedSchedule: Schedule) {
        val index = schedules.indexOfFirst { it.id == updatedSchedule.id }
        if (index != -1) {
            schedules[index] = updatedSchedule
        }
    }

    fun deleteSchedule(scheduleId: String) {
        schedules.removeIf { it.id == scheduleId }
    }

    fun getAllSchedules(): List<Schedule> {
        return schedules
    }

    fun getScheduleById(scheduleId: String): Schedule? {
        return schedules.find { it.id == scheduleId }
    }

    fun generateScheduleId(): String {
        val nextId = schedules.size + 1
        return "SC" + nextId.toString().padStart(3, '0')
    }
}
