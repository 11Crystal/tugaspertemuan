package com.example.student_management.repositories

import com.example.student_management.models.Teacher

class TeacherRepository {

    private val teachers = ArrayList<Teacher>()

    fun addTeacher(teacher: Teacher) {
        teachers.add(teacher)
    }

    fun updateTeacher(updatedTeacher: Teacher) {
        val index = teachers.indexOfFirst { it.id == updatedTeacher.id }
        if (index != -1) {
            teachers[index] = updatedTeacher
        }
    }

    fun deleteTeacher(teacherId: String) {
        teachers.removeIf { it.id == teacherId }
    }

    fun getAllTeachers(): List<Teacher> {
        return teachers
    }

    fun getTeacherById(teacherId: String): Teacher? {
        return teachers.find { it.id == teacherId }
    }

    fun generateTeacherId(): String {
        val nextId = teachers.size + 1
        return "T" + nextId.toString().padStart(3, '0')
    }
}
