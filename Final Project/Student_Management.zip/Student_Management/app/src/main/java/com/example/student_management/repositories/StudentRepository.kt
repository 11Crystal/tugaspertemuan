package com.example.student_management.repositories

import com.example.student_management.models.Student

class StudentRepository {

    // Database sementara menggunakan ArrayList
    private val students = ArrayList<Student>()

    // Tambah data
    fun addStudent(student: Student) {
        students.add(student)
    }

    // Update data
    fun updateStudent(updatedStudent: Student) {
        val index = students.indexOfFirst { it.id == updatedStudent.id }
        if (index != -1) {
            students[index] = updatedStudent
        }
    }

    // Hapus data
    fun deleteStudent(studentId: String) {
        students.removeIf { it.id == studentId }
    }

    // Dapatkan semua student
    fun getAllStudents(): List<Student> {
        return students
    }

    // Cari berdasarkan ID
    fun getStudentById(studentId: String): Student? {
        return students.find { it.id == studentId }
    }

    // Generate ID otomatis: S001, S002, S003
    fun generateStudentId(): String {
        val nextId = students.size + 1
        return "S" + nextId.toString().padStart(3, '0')
    }
}
