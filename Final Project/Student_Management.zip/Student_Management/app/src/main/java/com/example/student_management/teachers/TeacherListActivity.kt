package com.example.student_management.teachers

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityTeacherListBinding
import com.example.student_management.models.Teacher
import com.example.student_management.repositories.TeacherRepository

class TeacherListActivity : AppCompatActivity() {

    private lateinit var b: ActivityTeacherListBinding
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeacherListBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnAddTeacher.setOnClickListener {
            startActivity(Intent(this, TeacherFormActivity::class.java))
        }

        b.listTeachers.setOnItemClickListener { _, _, position, _ ->
            val teacher = TeacherRepository.teachers[position]
            val intent = Intent(this, TeacherDetailActivity::class.java)
            intent.putExtra("id", teacher.id)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        reloadList()
    }

    private fun reloadList() {
        val names = TeacherRepository.teachers.map { "${it.name} - ${it.subjectSpecialization}" }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        b.listTeachers.adapter = adapter
    }
}
