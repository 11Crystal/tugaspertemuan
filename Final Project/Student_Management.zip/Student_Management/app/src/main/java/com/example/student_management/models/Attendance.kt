package com.example.student_management.models

class Attendance(
    val id: String,                   // A001
    val studentId: String,            // S001
    val date: String,                 // "2025-11-27"
    var status: String                // "Present", "Absent", "Late"
)
