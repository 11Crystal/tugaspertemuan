package com.example.student_management

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.student_management.login.LoginActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // langsung pindah ke Login
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
