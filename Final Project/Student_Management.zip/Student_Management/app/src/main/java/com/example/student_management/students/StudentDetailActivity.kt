package com.example.student_management.students

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityStudentDetailBinding
import com.example.student_management.repositories.StudentRepository

class StudentDetailActivity : AppCompatActivity() {

    private lateinit var b: ActivityStudentDetailBinding
    private var studentId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityStudentDetailBinding.inflate(layoutInflater)
        setContentView(b.root)

        studentId = intent.getStringExtra("id")

        loadStudentData()

        b.btnEdit.setOnClickListener {
            val intent = Intent(this, StudentFormActivity::class.java)
            intent.putExtra("id", studentId)
            startActivity(intent)
        }

        b.btnDelete.setOnClickListener {
            confirmDelete()
        }
    }

    override fun onResume() {
        super.onResume()
        loadStudentData() // refresh data setelah edit
    }

    private fun loadStudentData() {
        val student = studentId?.let { StudentRepository.getStudentById(it) }

        if (student != null) {
            b.tvId.text = "ID: ${student.id}"
            b.tvName.text = "Name: ${student.name}"
            b.tvAddress.text = "Address: ${student.address}"
            b.tvParent.text = "Parent: ${student.parentName}"
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Confirm Delete")
            .setMessage("Are you sure you want to delete this student?")
            .setPositiveButton("Delete") { _: DialogInterface, _: Int ->
                studentId?.let { StudentRepository.deleteStudent(it) }
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
