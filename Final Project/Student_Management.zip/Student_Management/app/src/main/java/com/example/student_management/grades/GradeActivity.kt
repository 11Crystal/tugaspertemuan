package com.example.student_management.grades

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityGradeBinding
import com.example.student_management.models.Grade
import com.example.student_management.repositories.GradeRepository

class GradeActivity : AppCompatActivity() {

    private lateinit var b: ActivityGradeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGradeBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnAddGrade.setOnClickListener { showAddDialog() }

        reload()
    }

    private fun reload() {
        val list = GradeRepository.getAllGrades()
            .map { "${it.studentId} • ${it.subjectId} • ${it.gradeValue}" }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        b.listGrades.adapter = adapter
    }

    private fun showAddDialog() {
        val edtStudent = EditText(this)
        val edtSubject = EditText(this)
        val edtGrade = EditText(this)

        edtStudent.hint = "Student ID (S001)"
        edtSubject.hint = "Subject ID (SUB001)"
        edtGrade.hint = "Grade (0-100)"

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(40, 20, 40, 20)
        layout.addView(edtStudent)
        layout.addView(edtSubject)
        layout.addView(edtGrade)

        AlertDialog.Builder(this)
            .setTitle("Add Grade")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val sId = edtStudent.text.toString().trim()
                val subId = edtSubject.text.toString().trim()
                val value = edtGrade.text.toString().trim().toIntOrNull() ?: 0

                val id = GradeRepository.generateGradeId()

                GradeRepository.addGrade(
                    Grade(id, sId, subId, value)
                )

                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
