package com.example.student_management.attendance

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityAttendanceBinding
import com.example.student_management.models.Attendance
import com.example.student_management.repositories.AttendanceRepository
import java.text.SimpleDateFormat
import java.util.*

class AttendanceActivity : AppCompatActivity() {

    private lateinit var b: ActivityAttendanceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAttendanceBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnAddAttendance.setOnClickListener { showAddDialog() }
        reload()
    }

    private fun reload() {
        val list = AttendanceRepository.getAllAttendance().map { "${it.date} • ${it.studentId} • ${it.status}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        b.listAttendance.adapter = adapter
    }

    private fun showAddDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add Attendance")

        val inputStudent = EditText(this)
        inputStudent.hint = "Student ID (S001)"
        val inputStatus = EditText(this)
        inputStatus.hint = "Status (Present/Absent/Late)"

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(40,20,40,20)
        layout.addView(inputStudent)
        layout.addView(inputStatus)

        builder.setView(layout)
        builder.setPositiveButton("Save") { _, _ ->
            val studentId = inputStudent.text.toString().trim()
            val status = inputStatus.text.toString().trim().ifEmpty { "Present" }
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.format(Date())
            val id = AttendanceRepository.generateAttendanceId()
            AttendanceRepository.addAttendance(Attendance(id, studentId, date, status))
            reload()
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }
}
