package com.example.student_management.models

class Teacher(
    override val id: String,          // TXXX
    override var name: String,
    override var address: String,
    override var parentName: String,  // Wajib ikut Person → isi saja "-"
    var subjectSpecialization: String
) : Person(id, name, address, parentName)
