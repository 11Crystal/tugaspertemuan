package com.example.student_management.students

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityStudentFormBinding
import com.example.student_management.models.Student
import com.example.student_management.repositories.StudentRepository

class StudentFormActivity : AppCompatActivity() {

    private lateinit var b: ActivityStudentFormBinding
    private var editingStudent: Student? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityStudentFormBinding.inflate(layoutInflater)
        setContentView(b.root)

        val studentId = intent.getStringExtra("id")

        // Jika ID dikirimkan, berarti sedang edit
        if (studentId != null) {
            editingStudent = StudentRepository.getStudentById(studentId)
            editingStudent?.let { fillForm(it) }
        }

        b.btnSave.setOnClickListener {
            saveStudent()
        }
    }

    private fun fillForm(student: Student) {
        b.edtId.setText(student.id)
        b.edtId.isEnabled = false // ID tidak boleh diubah saat edit
        b.edtName.setText(student.name)
        b.edtAddress.setText(student.address)
        b.edtParent.setText(student.parentName)
    }

    private fun saveStudent() {
        val id = b.edtId.text.toString()
        val name = b.edtName.text.toString()
        val address = b.edtAddress.text.toString()
        val parent = b.edtParent.text.toString()

        // Validasi sederhana
        if (id.isEmpty() || name.isEmpty()) {
            Toast.makeText(this, "ID and Name are required", Toast.LENGTH_SHORT).show()
            return
        }

        if (editingStudent == null) {
            // tambah baru
            val newStudent = Student(id, name, address, parent)
            StudentRepository.addStudent(newStudent)
            Toast.makeText(this, "Student added", Toast.LENGTH_SHORT).show()
        } else {
            // update data
            editingStudent!!.name = name
            editingStudent!!.address = address
            editingStudent!!.parentName = parent
            Toast.makeText(this, "Student updated", Toast.LENGTH_SHORT).show()
        }

        finish()
    }
}
