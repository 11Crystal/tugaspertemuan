package com.example.student_management.repositories

import com.example.student_management.models.Attendance

class AttendanceRepository {

    private val attendances = ArrayList<Attendance>()

    fun addAttendance(attendance: Attendance) {
        attendances.add(attendance)
    }

    fun updateAttendance(updated: Attendance) {
        val index = attendances.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            attendances[index] = updated
        }
    }

    fun deleteAttendance(attendanceId: String) {
        attendances.removeIf { it.id == attendanceId }
    }

    fun getAllAttendance(): List<Attendance> {
        return attendances
    }

    fun getAttendanceById(attendanceId: String): Attendance? {
        return attendances.find { it.id == attendanceId }
    }

    fun generateAttendanceId(): String {
        val nextId = attendances.size + 1
        return "A" + nextId.toString().padStart(3, '0')
    }
}
