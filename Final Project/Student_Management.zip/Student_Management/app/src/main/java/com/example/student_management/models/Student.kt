package com.example.student_management.models

class Student(
    override val id: String,          // SXXX
    override var name: String,
    override var address: String,
    override var parentName: String,  // Nama orang tua
    var gradeLevel: String            // Kelas (X, XI, XII / A, B, C)
) : Person(id, name, address, parentName)
