package com.example.student_management.models

class Schedule(
    val id: String,                   // SC001
    val subjectId: String,            // SUB001
    val teacherId: String,            // T001
    val day: String,                  // "Monday"
    val time: String                  // "08:00 - 10:00"
)
