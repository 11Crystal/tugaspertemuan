package com.example.student_management.subjects

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.student_management.R
import com.example.student_management.models.Subject
import com.example.student_management.repositories.TeacherRepository

class SubjectAdapter(private val ctx: Context, private val data: ArrayList<Subject>) : BaseAdapter() {
    override fun getCount(): Int = data.size
    override fun getItem(position: Int): Any = data[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_subject, parent, false)
        val subject = data[position]
        v.findViewById<TextView>(R.id.tvSubjectName).text = subject.name
        val teacherName = TeacherRepository.getTeacherById(subject.teacherId)?.name ?: "-"
        v.findViewById<TextView>(R.id.tvSubjectTeacher).text = "Teacher: $teacherName"
        return v
    }
}
