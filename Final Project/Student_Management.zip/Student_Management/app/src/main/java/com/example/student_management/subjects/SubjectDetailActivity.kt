package com.example.student_management.subjects

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivitySubjectDetailBinding
import com.example.student_management.repositories.SubjectRepository

class SubjectDetailActivity : AppCompatActivity() {

    private lateinit var b: ActivitySubjectDetailBinding
    private var id: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySubjectDetailBinding.inflate(layoutInflater)
        setContentView(b.root)

        id = intent.getStringExtra("id")
        load()

        b.btnEditSubject.setOnClickListener {
            startActivity(Intent(this, SubjectFormActivity::class.java).putExtra("id", id))
        }

        b.btnDeleteSubject.setOnClickListener { confirmDelete() }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        val s = id?.let { SubjectRepository.getSubjectById(it) } ?: return
        b.tvSubjectId.text = "ID: ${s.id}"
        b.tvSubjectName.text = "Name: ${s.name}"
        b.tvSubjectTeacher.text = "Teacher ID: ${s.teacherId}"
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete subject?")
            .setPositiveButton("Delete") { _: DialogInterface, _: Int ->
                id?.let { SubjectRepository.deleteSubject(it) }
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
