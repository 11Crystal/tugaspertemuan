package com.example.student_management.reports

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.student_management.databinding.ActivityReportBinding
import com.example.student_management.repositories.*

class ReportActivity : AppCompatActivity() {

    private lateinit var b: ActivityReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityReportBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnReportStudents.setOnClickListener { reportStudents() }
        b.btnReportTeachers.setOnClickListener { reportTeachers() }
        b.btnReportSubjects.setOnClickListener { reportSubjects() }
        b.btnReportAttendance.setOnClickListener { reportAttendance() }
        b.btnReportGrades.setOnClickListener { reportGrades() }
    }

    private fun reportStudents() {
        val list = StudentRepository.getAllStudents()
        val text = list.joinToString("\n") {
            "${it.id} • ${it.name} • ${it.address} • Parent: ${it.parentName}"
        }
        b.tvOutput.text = text.ifEmpty { "No student data." }
    }

    private fun reportTeachers() {
        val list = TeacherRepository.getAllTeachers()
        val text = list.joinToString("\n") {
            "${it.id} • ${it.name} • ${it.phone}"
        }
        b.tvOutput.text = text.ifEmpty { "No teacher data." }
    }

    private fun reportSubjects() {
        val list = SubjectRepository.getAllSubjects()
        val text = list.joinToString("\n") {
            "${it.id} • ${it.name} • Teacher: ${it.teacherId}"
        }
        b.tvOutput.text = text.ifEmpty { "No subjects." }
    }

    private fun reportAttendance() {
        val list = AttendanceRepository.getAllAttendance()
        val text = list.joinToString("\n") {
            "${it.id} • ${it.studentId} • ${it.date} • ${it.status}"
        }
        b.tvOutput.text = text.ifEmpty { "No attendance records." }
    }

    private fun reportGrades() {
        val list = GradeRepository.getAllGrades()
        val text = list.joinToString("\n") {
            "${it.id} • ${it.studentId} • ${it.subjectId} • Grade: ${it.gradeValue}"
        }
        b.tvOutput.text = text.ifEmpty { "No grades." }
    }
}
